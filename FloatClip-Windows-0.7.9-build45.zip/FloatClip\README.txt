FloatClip 0.7.9 build45 / Windows x64
请完整解压，退出旧版 FloatClip 后替换安装文件。后续可使用应用内更新。
